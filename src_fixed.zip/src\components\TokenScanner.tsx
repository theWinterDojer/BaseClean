import { useEffect, useState, useCallback } from 'react';
import { useAccount } from 'wagmi';
import { Token, SpamFilters, TokenStatistics } from '@/types/token';
import { fetchTokenBalances, formatBalance, calculateTokenValue } from '@/lib/api';
import TokenList from './TokenList';
import FilterPanel from './FilterPanel';
import { useTokenFiltering } from '@/hooks/useTokenFiltering';

const VALUE_FILTERS = [1, 10, 50, 100];

export default function TokenScanner() {
    const { address, isConnected } = useAccount();
    const [tokens, setTokens] = useState<Token[]>([]);
    const [loading, setLoading] = useState(false);
    const [selectedTokens, setSelectedTokens] = useState<Set<string>>(new Set());
    const [maxValue, setMaxValue] = useState<number | null>(10);
    const [error, setError] = useState<string | null>(null);
    // Client-side rendering state to prevent hydration mismatch
    const [isClient, setIsClient] = useState(false);

    // Default spam filters - enable all for best detection
    const [spamFilters, setSpamFilters] = useState<SpamFilters>({
        namingIssues: true,
        valueIssues: true,
        airdropSignals: true,
        highRiskIndicators: true
    });

    // Set isClient to true once component mounts in the client
    useEffect(() => {
        setIsClient(true);
    }, []);

    const { spamTokens, nonSpamTokens } = useTokenFiltering(tokens, spamFilters, maxValue);

    // Toggle token selection
    const toggleToken = useCallback((contractAddress: string) => {
        setSelectedTokens(prev => {
            const newSet = new Set(prev);
            if (newSet.has(contractAddress)) {
                newSet.delete(contractAddress);
            } else {
                newSet.add(contractAddress);
            }
            return newSet;
        });
    }, []);

    // Select all spam tokens
    const selectAllSpam = useCallback(() => {
        setSelectedTokens(new Set(spamTokens.map(t => t.contract_address)));
    }, [spamTokens]);

    // Deselect all tokens
    const deselectAll = useCallback(() => setSelectedTokens(new Set()), []);

    // Handle burn selected tokens
    const handleBurnSelected = useCallback(() => {
        const selected = tokens.filter(token => selectedTokens.has(token.contract_address));
        
        // Check if any selected token has value > $0.01
        const valuableTokens = selected.filter(token => {
            const balance = formatBalance(token.balance, token.contract_decimals);
            const value = calculateTokenValue(balance, token.quote_rate);
            return value > 0.01; // More than 1 cent
        });

        if (valuableTokens.length > 0) {
            // Create a warning message with the valuable tokens
            const tokenList = valuableTokens.map(token => {
                const balance = formatBalance(token.balance, token.contract_decimals);
                const value = calculateTokenValue(balance, token.quote_rate);
                return `• ${token.contract_ticker_symbol || 'Unknown'}: $${value.toFixed(2)} (${balance.toLocaleString(undefined, {maximumFractionDigits: 4})})`;
            }).join('\n');

            const totalValue = valuableTokens.reduce((sum, token) => {
                const balance = formatBalance(token.balance, token.contract_decimals);
                return sum + calculateTokenValue(balance, token.quote_rate);
            }, 0);

            const confirmBurn = window.confirm(
                `⚠️ WARNING: You're about to burn tokens worth $${totalValue.toFixed(2)}!\n\n` +
                `The following tokens have value:\n${tokenList}\n\n` +
                `Are you sure you want to proceed with burning these tokens?`
            );

            if (confirmBurn) {
                // Proceed with burning
                alert(`🔥 Burning ${selected.length} token(s), including ${valuableTokens.length} valuable token(s).`);
            }
        } else {
            // No valuable tokens, proceed without warning
            alert(`🔥 Burning ${selected.length} token(s) with no significant value.`);
        }
    }, [tokens, selectedTokens]);

    // Fetch tokens when connected
    useEffect(() => {
        if (!isConnected || !address) return;
        
        const getTokens = async () => {
            setLoading(true);
            setError(null);
            
            try {
                const tokenItems = await fetchTokenBalances(address);
                setTokens(tokenItems);
            } catch (err) {
                console.error('Failed to fetch tokens:', err);
                setError('Failed to load tokens. Please try again.');
            } finally {
                setLoading(false);
            }
        };

        getTokens();
    }, [address, isConnected]);

    // Statistics data for display
    const statistics: TokenStatistics = {
        totalTokens: tokens.length,
        spamTokens: spamTokens.length,
        regularTokens: nonSpamTokens.length,
        selectedTokens: selectedTokens.size,
        spamPercentage: tokens.length > 0 ? Math.round((spamTokens.length / tokens.length) * 100) : 0
    };

    return (
        <section className="mt-10 space-y-10 text-sm" aria-labelledby="wallet-token-management">
            {/* Not connected message - only show on client to avoid hydration mismatch */}
            {isClient && !isConnected && (
                <div className="bg-blue-900/30 border border-blue-700 text-white p-4 rounded flex items-center justify-center">
                    <span className="text-lg">Please connect your wallet to view your token balances</span>
                </div>
            )}

            {/* Error message */}
            {error && (
                <div className="bg-red-800/30 border border-red-600 text-white p-4 rounded" role="alert">
                    {error}
                </div>
            )}

            {/* Loading indicator */}
            {loading ? (
                <div className="flex items-center justify-center h-40">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500" aria-label="Loading..."></div>
                </div>
            ) : (isClient && isConnected) && (
                <>
                    {/* Selected tokens info - Improved styling for better visibility */}
                    {selectedTokens.size > 0 && (
                        <div className="bg-gradient-to-r from-green-900/20 to-green-800/20 border border-green-700 rounded-lg p-5 shadow-lg">
                            <div className="flex flex-wrap items-center justify-between gap-4">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-green-700/40 rounded-full flex items-center justify-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-300" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M3 6a3 3 0 013-3h10a1 1 0 01.8 1.6L14.25 8l2.55 3.4A1 1 0 0116 13H6a1 1 0 00-1 1v3a1 1 0 11-2 0V6z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-semibold text-green-300">
                                            {selectedTokens.size} {selectedTokens.size > 1 ? 'Tokens' : 'Token'} Selected
                                        </h3>
                                        <p className="text-sm text-green-500/80">Ready to clean from your wallet</p>
                                    </div>
                                </div>
                                <div className="flex gap-3">
                                    <button
                                        onClick={deselectAll}
                                        className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 rounded-md text-sm font-medium transition-colors flex items-center gap-2"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                        </svg>
                                        Clear Selection
                                    </button>
                                    <button
                                        onClick={handleBurnSelected}
                                        className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm font-medium transition-colors shadow-md hover:shadow-lg flex items-center gap-2"
                                        aria-label={`Burn ${selectedTokens.size} selected tokens`}
                                        disabled={selectedTokens.size === 0}
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z" clipRule="evenodd" />
                                        </svg>
                                        Burn Selected Tokens
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Filters Panel - removed outer div to use FilterPanel's new structure */}
                    <FilterPanel
                        spamFilters={spamFilters}
                        setSpamFilters={setSpamFilters}
                        maxValue={maxValue}
                        setMaxValue={setMaxValue}
                        valueFilters={VALUE_FILTERS}
                    />

                    {/* Selection Buttons - Improved appearance */}
                    <div className="bg-gray-800/40 border border-gray-700 rounded-lg p-5">
                        <h3 className="text-xl font-semibold text-green-300 mb-4 flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z" />
                                <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h8a2 2 0 00-2-2H5z" />
                            </svg>
                            Bulk Actions
                        </h3>
                        <div className="flex flex-wrap gap-4">
                            <button
                                onClick={selectAllSpam}
                                className="bg-gradient-to-r from-red-700 to-red-600 hover:from-red-600 hover:to-red-500 text-white px-5 py-2.5 rounded-md text-sm font-medium transition-colors shadow-md hover:shadow-lg flex items-center gap-2"
                                disabled={spamTokens.length === 0}
                                aria-label={`Select all ${spamTokens.length} spam tokens`}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H4zm0 3a1 1 0 100 2h6a1 1 0 100-2H4z" clipRule="evenodd" />
                                </svg>
                                Select All Spam Tokens ({spamTokens.length})
                            </button>
                            <button
                                onClick={deselectAll}
                                className="bg-gray-700 hover:bg-gray-600 text-white px-5 py-2.5 rounded-md text-sm font-medium transition-colors flex items-center gap-2"
                                disabled={selectedTokens.size === 0}
                                aria-label="Deselect all tokens"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                                Deselect All
                            </button>
                        </div>
                    </div>

                    {/* Token Statistics - Made more visually distinct */}
                    <div className="bg-gray-800/30 border border-gray-700 rounded-lg p-5">
                        <h3 className="text-xl font-semibold text-green-300 mb-4 flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M3 6a3 3 0 013-3h12a1 1 0 110 2H6a2 2 0 00-2 2v8a2 2 0 002 2h12a1 1 0 110 2H6a4 4 0 01-4-4V6a3 3 0 013-3z" clipRule="evenodd" />
                            </svg>
                            Token Summary
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                            <div className="bg-gray-800/50 border border-gray-700 p-4 rounded-lg shadow-md hover:shadow-lg transition-all">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 rounded-full bg-blue-600/30 flex items-center justify-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z" />
                                            <path fillRule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <div className="text-sm text-gray-400">Total Tokens</div>
                                </div>
                                <div className="text-2xl font-bold text-white mt-2">{statistics.totalTokens}</div>
                                <div className="text-xs text-gray-500 mt-1">All tokens in wallet</div>
                            </div>
                            
                            <div className="bg-red-900/20 border border-red-800/50 p-4 rounded-lg shadow-md hover:shadow-lg transition-all">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 rounded-full bg-red-600/30 flex items-center justify-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <div className="text-sm text-red-400">Spam Tokens</div>
                                </div>
                                <div className="text-2xl font-bold text-red-300 mt-2">{statistics.spamTokens}</div>
                                <div className="text-xs text-red-400/80 mt-1">{statistics.spamTokens > 0 ? `${statistics.spamPercentage}% of total` : 'None detected'}</div>
                            </div>
                            
                            <div className="bg-gray-800/50 border border-gray-700 p-4 rounded-lg shadow-md hover:shadow-lg transition-all">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 rounded-full bg-blue-600/30 flex items-center justify-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <div className="text-sm text-gray-400">Regular Tokens</div>
                                </div>
                                <div className="text-2xl font-bold text-white mt-2">{statistics.regularTokens}</div>
                                <div className="text-xs text-gray-500 mt-1">Legitimate tokens</div>
                            </div>
                            
                            <div className="bg-green-900/20 border border-green-800/50 p-4 rounded-lg shadow-md hover:shadow-lg transition-all">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 rounded-full bg-green-600/30 flex items-center justify-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                        </svg>
                                    </div>
                                    <div className="text-sm text-green-400">Selected</div>
                                </div>
                                <div className="text-2xl font-bold text-green-300 mt-2">{statistics.selectedTokens}</div>
                                <div className="text-xs text-green-500/80 mt-1">{statistics.selectedTokens > 0 ? 'Ready to clean' : 'Select tokens to clean'}</div>
                            </div>
                        </div>
                    </div>

                    {/* Token Lists - Improved layout for clarity */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        {/* Suspected Spam Tokens */}
                        <div className="h-full">
                            <div className="bg-red-900/10 border border-red-900/30 rounded-lg overflow-hidden h-full">
                                <div className="flex items-center justify-between gap-2 bg-red-900/20 p-4 border-b border-red-900/30">
                                    <div className="flex items-center gap-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                        </svg>
                                        <h3 className="text-xl font-bold text-red-400">Suspected Spam Tokens</h3>
                                    </div>
                                    <span className="bg-red-800/50 text-red-200 text-xs px-2 py-1 rounded-full">{spamTokens.length} tokens</span>
                                </div>
                                {spamTokens.length > 0 ? (
                                    <TokenList 
                                        tokens={spamTokens}
                                        selectedTokens={selectedTokens}
                                        toggleToken={toggleToken}
                                        isSpam={true}
                                    />
                                ) : (
                                    <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                        </svg>
                                        <p className="text-gray-400">No spam tokens detected with current filters</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Regular Tokens */}
                        <div className="h-full">
                            <div className="bg-gray-800/40 border border-gray-700 rounded-lg overflow-hidden h-full">
                                <div className="flex items-center justify-between gap-2 bg-gray-800/60 p-4 border-b border-gray-700">
                                    <div className="flex items-center gap-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                                            <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                        </svg>
                                        <h3 className="text-xl font-bold text-blue-400">Regular Tokens</h3>
                                    </div>
                                    <span className="bg-blue-800/50 text-blue-200 text-xs px-2 py-1 rounded-full">{nonSpamTokens.length} tokens</span>
                                </div>
                                {nonSpamTokens.length > 0 ? (
                                    <TokenList 
                                        tokens={nonSpamTokens}
                                        selectedTokens={selectedTokens}
                                        toggleToken={toggleToken}
                                    />
                                ) : (
                                    <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 12H4" />
                                        </svg>
                                        <p className="text-gray-400">No regular tokens match current filters</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </>
            )}
        </section>
    );
}