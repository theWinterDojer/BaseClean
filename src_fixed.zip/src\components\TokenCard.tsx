import { Token } from '@/types/token';
import { formatBalance, calculateTokenValue, getTokenLogoUrl } from '@/lib/api';
import { useState, useEffect, memo, useCallback } from 'react';
import Image from 'next/image';

interface TokenCardProps {
  token: Token;
  onTokenSelect?: (token: Token) => void;
  isSelected?: boolean;
}

const TokenCard = memo(function TokenCard({ token, onTokenSelect, isSelected = false }: TokenCardProps) {
  const [imageUrl, setImageUrl] = useState<string | null>(token.logo_url || null);
  const [isLoadingImage, setIsLoadingImage] = useState(true);
  const [imageError, setImageError] = useState(false);
  const [hover, setHover] = useState(false);
  
  const formattedBalance = formatBalance(token.balance, token.contract_decimals);
  const tokenValue = calculateTokenValue(token.balance, token.quote_rate);

  // Load token image
  useEffect(() => {
    const loadImage = async () => {
      setIsLoadingImage(true);
      setImageError(false);
      
      try {
        // If logo_url already exists in token data, try to use it first
        if (token.logo_url) {
          setImageUrl(token.logo_url);
        } else {
          // Otherwise fetch a logo URL
          const url = await getTokenLogoUrl(
            token.contract_address, 
            token.contract_ticker_symbol
          );
          setImageUrl(url || null);
        }
      } catch (err) {
        console.warn(`Failed to load image for ${token.contract_ticker_symbol || token.contract_address}:`, err);
        setImageError(true);
      } finally {
        setIsLoadingImage(false);
      }
    };
    
    loadImage();
  }, [token.contract_address, token.contract_ticker_symbol, token.logo_url]);

  const handleCardClick = () => {
    if (onTokenSelect) {
      onTokenSelect(token);
    }
  };
  
  const handleImageError = useCallback(() => {
    setImageError(true);
    // Try to get a fallback image
    getTokenLogoUrl(token.contract_address, token.contract_ticker_symbol)
      .then(url => {
        if (url && url !== imageUrl) {
          setImageUrl(url);
          setImageError(false);
        }
      })
      .catch(() => {
        // Keep the error state if fallback fails
      });
  }, [token.contract_address, token.contract_ticker_symbol, imageUrl]);

  return (
    <div 
      className={`p-4 rounded-lg cursor-pointer transition-all duration-200 ${
        isSelected 
          ? 'bg-blue-100 dark:bg-blue-900/30 border border-blue-300 dark:border-blue-700' 
          : hover 
            ? 'bg-gray-100 dark:bg-gray-800/50' 
            : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700'
      }`}
      onClick={handleCardClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div className="flex items-center">
        <div className="relative w-10 h-10 mr-3 rounded-full overflow-hidden bg-gray-100 dark:bg-gray-700">
          {isLoadingImage ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-gray-200 border-t-blue-500 rounded-full animate-spin"></div>
            </div>
          ) : imageUrl && !imageError ? (
            <Image
              src={imageUrl}
              alt={token.contract_ticker_symbol || 'Token'}
              width={40}
              height={40}
              className="object-cover"
              onError={handleImageError}
              priority={token.quote_rate > 0}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center bg-blue-500 text-white font-bold text-lg">
              {token.contract_ticker_symbol ? token.contract_ticker_symbol.substring(0, 1) : '?'}
            </div>
          )}
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                {token.contract_ticker_symbol || 'Unknown Token'}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-[180px]" title={token.contract_name}>
                {token.contract_name || token.contract_address.substring(0, 8) + '...'}
              </p>
            </div>
            <div className="text-right">
              <p className="font-medium text-gray-900 dark:text-gray-100">
                {formattedBalance}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {tokenValue ? `$${tokenValue}` : '-'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

export default TokenCard; 