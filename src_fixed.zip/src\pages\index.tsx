import { ConnectButton } from '@rainbow-me/rainbowkit';
import TokenScanner from '@/components/TokenScanner';
import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>BaseClean - Clean your wallet from spam tokens</title>
        <meta name="description" content="Easily identify and burn spam tokens on Base blockchain" />
      </Head>
      
      <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
        <header className="border-b border-gray-800 p-4 flex justify-between items-center">
          <h1 className="text-3xl font-bold">🧹 BaseClean</h1>
          <ConnectButton />
        </header>
        
        <main className="container mx-auto px-4 py-6">
          <TokenScanner />
        </main>
        
        <footer className="mt-20 border-t border-gray-800 p-4 text-center text-gray-500 text-sm">
          <p>BaseClean - Clean your wallet from spam tokens on Base</p>
        </footer>
      </div>
    </>
  );
}