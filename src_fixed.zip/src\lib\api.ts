import { Token } from '@/types/token';

// Use environment variable with type checking and proper error handling
const BLOCKCHAIN_API_KEY = process.env.NEXT_PUBLIC_BLOCKCHAIN_API_KEY || '';

// Enhanced cache for token logo URLs with permanent storage
const TOKEN_LOGO_CACHE: Record<string, string> = {};

// Define missing types
type CovalentResponse = {
  data: {
    items: CovalentItem[];
  };
  error: boolean;
  error_message: string | null;
};

type CovalentItem = {
  type: string;
  contract_address: string;
  contract_ticker_symbol: string;
  contract_name: string;
  balance: string;
  contract_decimals: number;
  quote_rate: number;
  logo_url?: string;
};

// Load cache from localStorage if available (client-side only)
if (typeof window !== 'undefined') {
  try {
    const cachedLogos = localStorage.getItem('token_logo_cache');
    if (cachedLogos) {
      Object.assign(TOKEN_LOGO_CACHE, JSON.parse(cachedLogos));
    }
  } catch (e) {
    console.debug('Failed to load token logo cache from localStorage');
  }
}

/**
 * Save token logo URL to cache including localStorage
 */
const saveToCache = (address: string, url: string): void => {
  // Always update in-memory cache
  TOKEN_LOGO_CACHE[address] = url;
  
  // Update localStorage if available (client-side only)
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('token_logo_cache', JSON.stringify(TOKEN_LOGO_CACHE));
    } catch (e) {
      console.debug('Failed to save token logo cache to localStorage');
    }
  }
};

/**
 * Safe btoa function that works with all characters and environments
 */
function safeEncode(str: string): string {
  try {
    // First, UTF-8 encode the string to handle special characters
    const utf8Bytes = new TextEncoder().encode(str);
    // Convert to base64 using only visible ASCII
    const base64 = btoa(
      Array.from(utf8Bytes)
        .map(byte => String.fromCharCode(byte))
        .join('')
    );
    return base64;
  } catch (error) {
    console.warn('Error in safeEncode:', error);
    
    // Last resort fallback - create a simpler encoded string
    try {
      // Use only ASCII characters that are safe for base64
      return btoa(str.replace(/[^\x00-\x7F]/g, '_'));
    } catch (e) {
      // Ultra-safe fallback if everything fails
      return 'PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0MCA0MCIgaGVpZ2h0PSI0MCIgd2lkdGg9IjQwIj48Y2lyY2xlIGN4PSIyMCIgY3k9IjIwIiByPSIyMCIgZmlsbD0iIzYwN0Q4QiIvPjx0ZXh0IHg9IjIwIiB5PSIyNSIgZm9udC1zaXplPSIxNiIgZmlsbD0iI2ZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+WDwvdGV4dD48L3N2Zz4=';
    }
  }
}

/**
 * Well-known token addresses with pre-verified GitHub image URLs
 * These URLs are guaranteed to be CORS-friendly and reliable
 */
const COMMON_TOKEN_IMAGES: Record<string, string> = {
  // Major tokens by address
  '0x4200000000000000000000000000000000000006': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png', // ETH on Base
  '0xa9a489ea2ba0e0af84150f88d1c33c866f466a80': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/0xA9A489EA2Ba0E0Af84150f88D1c33C866f466A80/logo.png', // ZORA
  '0x833589fcd6edb6e08f4c7c32d4f71b54bda02913': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/0x833589fCD6eDb6E08f4c7C32d4f71b54bdA02913/logo.png', // USDC
  '0x50c5725949a6f0c72e6c4a641f24049a917db0cb': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/0x50c5725949A6F0c72e6c4a641f24049A917DB0Cb/logo.png', // DAI
  
  // By symbol for quick lookups
  'eth': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png',
  'weth': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png',
  'usdc': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/0x833589fCD6eDb6E08f4c7C32d4f71b54bdA02913/logo.png',
  'usdt': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/ethereum/assets/0xdAC17F958D2ee523a2206206994597C13D831ec7/logo.png',
  'dai': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/0x50c5725949A6F0c72e6c4a641f24049A917DB0Cb/logo.png',
  'zora': 'https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/0xA9A489EA2Ba0E0Af84150f88D1c33C866f466A80/logo.png',
};

/**
 * Improved token logo resolver that eliminates CORS issues
 * Using only reliable GitHub sources and enhanced SVG fallbacks
 */
export async function getTokenLogoUrl(address: string, symbol: string = ''): Promise<string | undefined> {
  const cleanAddress = address?.toLowerCase();
  const cleanSymbol = symbol?.toLowerCase();
  
  if (!cleanAddress || cleanAddress === '0x0000000000000000000000000000000000000000') {
    return undefined;
  }

  // First check the in-memory/localStorage cache
  if (TOKEN_LOGO_CACHE[cleanAddress]) {
    return TOKEN_LOGO_CACHE[cleanAddress];
  }

  // Check for common tokens with known reliable URLs
  if (COMMON_TOKEN_IMAGES[cleanAddress]) {
    const url = COMMON_TOKEN_IMAGES[cleanAddress];
    saveToCache(cleanAddress, url);
    return url;
  }
  
  if (cleanSymbol && COMMON_TOKEN_IMAGES[cleanSymbol]) {
    const url = COMMON_TOKEN_IMAGES[cleanSymbol];
    saveToCache(cleanAddress, url);
    return url;
  }
  
  // Use only GitHub repositories and other CORS-friendly sources
  const urlsToTry = [
    // Uniswap repository (very comprehensive and reliable)
    `https://raw.githubusercontent.com/Uniswap/assets/master/blockchains/base/assets/${cleanAddress}/logo.png`,
    
    // TrustWallet repository (very comprehensive)
    `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/base/assets/${cleanAddress}/logo.png`,
    
    // Base.org assets repository 
    `https://raw.githubusercontent.com/base-org/assets/main/blockchains/base/assets/${cleanAddress}/logo.png`,
    
    // Community repositories
    `https://raw.githubusercontent.com/dorianbayart/CryptoLogos/main/dist/base/${cleanAddress}.png`,
    
    // 1inch repository (good coverage, CORS-friendly)
    `https://tokens.1inch.io/${cleanAddress}.png`,
  ];
  
  // Try each source sequentially until we find a working one
  for (const url of urlsToTry) {
    try {
      const response = await fetch(url, { 
        method: 'HEAD',
        // Short timeout to avoid waiting too long
        signal: AbortSignal.timeout(800)
      });
      
      if (response.ok) {
        saveToCache(cleanAddress, url);
        return url;
      }
    } catch (e) {
      // Silently continue to the next URL
    }
  }
  
  // If all external URLs fail, generate an SVG based on token info
  const initialChar = cleanSymbol && cleanSymbol.length > 0 ? 
    cleanSymbol.substring(0, Math.min(2, cleanSymbol.length)).toUpperCase() : 
    cleanAddress.substring(2, 4).toUpperCase();
  
  // Generate a deterministic color from the address
  // Using a simpler hash method that's reliable and maintains visual consistency
  const addressSeed = parseInt(cleanAddress.substring(2, 10), 16);
  
  // Color palette based on material design
  const colors = [
    '#F44336', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5',
    '#2196F3', '#03A9F4', '#00BCD4', '#009688', '#4CAF50',
    '#8BC34A', '#CDDC39', '#FFEB3B', '#FFC107', '#FF9800'
  ];
  
  const colorIndex = addressSeed % colors.length;
  const bgColor = colors[colorIndex];
  
  // Create a simple but visually distinctive SVG
  const svgContent = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="40" height="40">
  <circle cx="20" cy="20" r="20" fill="${bgColor}"/>
  <text x="20" y="25" font-family="Arial, sans-serif" font-size="${initialChar.length > 1 ? '14' : '16'}" font-weight="bold" text-anchor="middle" fill="white">${initialChar}</text>
</svg>`;
  
  // Create a data URI with the SVG and encode it safely
  const dataUri = `data:image/svg+xml;base64,${safeEncode(svgContent.trim())}`;
  saveToCache(cleanAddress, dataUri);
  return dataUri;
}

/**
 * Fetches token balances for a given address
 * 
 * @param address - The wallet address to fetch balances for
 * @returns Promise<Token[]> - Array of tokens or empty array on error
 */
export const fetchTokenBalances = async (address: string): Promise<Token[]> => {
  if (!address) {
    console.error('No address provided to fetchTokenBalances');
    return [];
  }

  try {
    if (!BLOCKCHAIN_API_KEY) {
      console.error('Missing blockchain API key');
      throw new Error('API key not configured');
    }

    const res = await fetch(
      `https://api.covalenthq.com/v1/base-mainnet/address/${address}/balances_v2/?key=${BLOCKCHAIN_API_KEY}`,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
    
    if (!res.ok) {
      throw new Error(`API error: ${res.status}`);
    }
    
    const data: CovalentResponse = await res.json();

    if (data.error) {
      throw new Error(`Covalent API error: ${data.error_message}`);
    }

    const tokens = data.data.items.filter(
      (item: CovalentItem) => item.type === 'cryptocurrency'
    );
    
    // Process tokens with parallel logo fetching and enhanced price data
    const processedTokens = await Promise.all(
      tokens.map(async (item) => {
        // Get token logo URL with the new simplified function
        const logoUrl = await getTokenLogoUrl(
          item.contract_address,
          item.contract_ticker_symbol || ''
        );

        // Initial token with Covalent data
        const token = {
          contract_address: item.contract_address,
          contract_ticker_symbol: item.contract_ticker_symbol || '',
          contract_name: item.contract_name || '',
          balance: item.balance,
          contract_decimals: item.contract_decimals,
          quote_rate: item.quote_rate,
          logo_url: logoUrl,
          price_source: 'covalent'
        };

        // If token has no price data from Covalent, try fetching from alternative sources
        if (token.quote_rate === 0 && token.contract_ticker_symbol) {
          try {
            // Try DefiLlama first (fast API, no rate limits)
            const defiLlamaPrice = await fetchDefiLlamaPrice(token.contract_address);
            if (defiLlamaPrice > 0) {
              token.quote_rate = defiLlamaPrice;
              token.price_source = 'defillama';
              return token;
            }

            // If DefiLlama fails, try CoinGecko as fallback
            const coingeckoPrice = await fetchCoinGeckoPrice(token.contract_address);
            if (coingeckoPrice > 0) {
              token.quote_rate = coingeckoPrice;
              token.price_source = 'coingecko';
              return token;
            }
          } catch (err) {
            console.debug(`Failed to fetch alternative price data for ${token.contract_ticker_symbol}:`, err);
          }
        }
        
        return token;
      })
    );

    return processedTokens;
  } catch (err) {
    console.error('Failed to fetch tokens:', err);
    return [];
  }
};

/**
 * Fetch token price from DefiLlama API
 * 
 * @param address Contract address to fetch price for
 * @returns Price in USD or 0 if not found
 */
async function fetchDefiLlamaPrice(address: string): Promise<number> {
  try {
    const response = await fetch(`https://coins.llama.fi/prices/current/base:${address}`);
    
    if (!response.ok) {
      return 0;
    }
    
    const data = await response.json();
    const priceKey = `base:${address.toLowerCase()}`;
    
    return data.coins?.[priceKey]?.price || 0;
  } catch (err) {
    console.debug(`DefiLlama price fetch failed for ${address}:`, err);
    return 0;
  }
}

/**
 * Fetch token price from CoinGecko API
 * 
 * @param address Contract address to fetch price for
 * @returns Price in USD or 0 if not found
 */
async function fetchCoinGeckoPrice(address: string): Promise<number> {
  try {
    // Note: Free API has strict rate limits (10-20 calls/min)
    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/token_price/base?contract_addresses=${address}&vs_currencies=usd`,
      { 
        headers: { 'accept': 'application/json' }
      }
    );
    
    if (!response.ok) {
      return 0;
    }
    
    const data = await response.json();
    return data[address.toLowerCase()]?.usd || 0;
  } catch (err) {
    console.debug(`CoinGecko price fetch failed for ${address}:`, err);
    return 0;
  }
}

/**
 * Format token balance with appropriate decimals
 * @param balance The token balance as a string
 * @param decimals The number of decimals the token uses
 * @returns The formatted balance as a number
 */
export function formatBalance(balance: string, decimals: number): string {
  if (!balance || isNaN(decimals)) {
    return '0';
  }
  
  try {
    // Parse the balance
    const parsedBalance = parseFloat(balance);
    if (isNaN(parsedBalance)) return '0';
    
    // Get the balance with proper decimal places
    const adjustedBalance = parsedBalance / Math.pow(10, decimals);
    
    // Format based on size
    if (adjustedBalance >= 1000000) {
      return (adjustedBalance / 1000000).toFixed(2) + 'M';
    } else if (adjustedBalance >= 1000) {
      return (adjustedBalance / 1000).toFixed(2) + 'K';
    } else if (adjustedBalance >= 1) {
      return adjustedBalance.toFixed(2);
    } else if (adjustedBalance > 0) {
      // For very small numbers, show more decimal places
      return adjustedBalance.toFixed(Math.min(6, decimals));
    } else {
      return '0';
    }
  } catch (error) {
    console.error('Error formatting balance:', error);
    return '0';
  }
}

/**
 * Calculate the USD value of a token
 * @param balance The token balance as a string
 * @param quoteRate The token's price in USD
 * @returns The token value formatted as a string
 */
export function calculateTokenValue(balance: string, quoteRate: number): string {
  if (!balance || !quoteRate) return '';
  
  try {
    // Parse the balance as a float
    const balanceFloat = parseFloat(balance);
    if (isNaN(balanceFloat)) return '';
    
    // Calculate the value
    const value = balanceFloat * quoteRate;
    
    // Format based on value size
    if (value >= 1000000) {
      return (value / 1000000).toFixed(2) + 'M';
    } else if (value >= 1000) {
      return (value / 1000).toFixed(2) + 'K';
    } else if (value >= 1) {
      return value.toFixed(2);
    } else if (value > 0) {
      return value.toFixed(4);
    } else {
      return '0.00';
    }
  } catch (error) {
    console.error('Error calculating token value:', error);
    return '';
  }
} 